<?php require_once('./private/initialize.php'); ?>


<?php

$url = $_SERVER['REQUEST_URI'];
if(strpos($url,"/") !== 0){
    $url = "/$url";
}
$urlArr = explode("/", $url);

header('Access-Control-Allow-Origin: *');
header("Content-Type:application/json");




if($_SERVER['REQUEST_METHOD'] == 'GET') {
  $furnitures = Furniture::find_all();
    echo json_encode($furnitures);
}


if($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    
$data = json_decode(file_get_contents("php://input"));
$del = $data -> delete;
  
  

  if($del == 0){
      
 
  $product = new Product();
  $product -> settype_(trim($url, "/"));
  $result2 = $product -> save();
  $id_prod = $database -> insert_id;

  $furniture = new Furniture();
  

  $furniture->setid($id_prod);
  $furniture->setSKU($data-> SKU);
  $furniture->setname_($data->name_);
  $furniture->setprice($data->price);
  $furniture->setH($data->H);
  $furniture->setW($data->W);
  $furniture->setL($data->L);

  $result = $furniture->save();

 

  if($result === true && $result2 === true) {
    $new_id = $furniture->id;
    $_SESSION['message'] = 'The furniture was created successfully.';
    echo json_encode($furniture);
  } else {
    // show errors
  }
  }
} 

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $data = json_decode(file_get_contents("php://input"));
    $del = $data -> delete;
    
    if ($del == 1){
        
        $furniture = Furniture::find_by_id($data-> id);
        $result = $furniture->delete();
  
        echo json_encode($furniture);
    }

}
 

  


?>
