<?php require_once('./private/initialize.php'); ?>


<?php

$url = $_SERVER['REQUEST_URI'];
if(strpos($url,"/") !== 0){
    $url = "/$url";
}
$urlArr = explode("/", $url);

header('Access-Control-Allow-Origin: *');
header("Content-Type: application/JSON");

//For Delete I used a post method with a delete attribute = 1


if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $data = json_decode(file_get_contents("php://input"));
    $del = $data -> delete;
    
    if ($del == 1){
        
        $book = Book::find_by_id($data-> id);
        $result = $book->delete();
  
        echo json_encode($book);
    }

}




if($_SERVER['REQUEST_METHOD'] == 'GET') {
  $books = Book::find_all();
    echo json_encode($books);
}


if($_SERVER['REQUEST_METHOD'] == 'POST') {
  
  
 
  
  $data = json_decode(file_get_contents("php://input"));
  $del = $data -> delete;
  
  if ($del == 0){
  

  
    $product = new Product();
    $product -> settype_(trim($url, "/"));
    $result2 = $product -> save();
    $id_prod = $database -> insert_id;

    $book = new Book();
  

    $book->setid($id_prod);
    $book->setSKU($data-> SKU);
    $book->setname_($data->name_);
    $book->setprice($data->price);
    $book->setweight($data->weight);

    $result = $book->save();

    

    if($result === true && $result2 === true) {
        $new_id = $book->id;
        $_SESSION['message'] = 'The book was created successfully.';
        echo json_encode($book);
    } else {
    // show errors
        }
  }
} 





?>
      
