<?php

$routes = [
    'book' => 'book.php',
    'dvd' => 'dvd.php',
    'furniture' => 'furniture.php',
    'all' => 'getall.php'
];

