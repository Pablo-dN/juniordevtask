<?php require_once('./private/initialize.php'); ?>


<?php

$url = $_SERVER['REQUEST_URI'];
if(strpos($url,"/") !== 0){
    $url = "/$url";
}
$urlArr = explode("/", $url);

header('Access-Control-Allow-Origin: *');
header("Content-Type:application/json");




if($_SERVER['REQUEST_METHOD'] == 'GET') {
  
    
    $books = Book::find_all();
    $furnitures = Furniture::find_all();
    $dvds = DVD::find_all();

    $result = array_merge( $books, $furnitures, $dvds);

    usort($result ,function($first,$second){
        return $first->id > $second->id;
    });

    echo json_encode($result);


}

?>