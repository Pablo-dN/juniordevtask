<?php require_once('./private/initialize.php'); ?>


<?php

$url = $_SERVER['REQUEST_URI'];
if(strpos($url,"/") !== 0){
    $url = "/$url";
}
$urlArr = explode("/", $url);

header('Access-Control-Allow-Origin: *');
header("Content-Type:application/json");



if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $data = json_decode(file_get_contents("php://input"));
    $del = $data -> delete;
    
    if ($del == 1){
        
        $dvd = DVD::find_by_id($data-> id);
        $result = $dvd->delete();
  
        echo json_encode($dvd);
    }

}


if($_SERVER['REQUEST_METHOD'] == 'GET') {
  $dvds = DVD::find_all();
    echo json_encode($dvds);
}





if($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $data = json_decode(file_get_contents("php://input"));
    $del = $data -> delete;
  
  


  if ($del == 0) {
  
  $product = new Product();
  $product -> settype_(trim($url, "/"));
  $result2 = $product -> save();
  $id_prod = $database -> insert_id;

  $dvd = new DVD();
  

  $dvd->setid($id_prod);
  $dvd->setSKU($data-> SKU);
  $dvd->setname_($data->name_);
  $dvd->setprice($data->price);
  $dvd->setsize($data->size);

  $result = $dvd->save();

 

  if($result === true && $result2 === true) {
    $new_id = $dvd->id;
    $_SESSION['message'] = 'The dvd was created successfully.';
    echo json_encode($dvd);
  } else {
    // show errors
  }
  }
} 

  

  


?>