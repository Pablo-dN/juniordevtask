<?php require_once('./private/initialize.php'); ?>

<?php require __DIR__.'/private/classes/Router.class.php';

require __DIR__.'/routes.php';?>

<?php
    
  header('Access-Control-Allow-Origin: *');
  header("Content-Type: application/JSON");

   


  $router = new Router;
  $router->setRoutes($routes);
  
  $url = $_SERVER['REQUEST_URI'];
  require __DIR__."/".$router->getFilename($url);
  


//this is the endpoint, which file to go next is managed by the router class
//I decided to use separate files for each type because I designed the database
//with 4 tables: one for each type (with the corresponding characteristics) and a parent table with the id element and type.
?>


