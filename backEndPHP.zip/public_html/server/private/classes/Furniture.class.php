<?php

class Furniture extends DatabaseObject {

  static protected $table_name = 'furniture';
  static protected $db_columns = ['id', 'id_el', 'SKU', 'name_', 'price', 'H', 'W', 'L'];

  public $id;
  public $id_el;
  public $SKU;
  public $name_;
  public $price;
  public $H;
  public $W;
  public $L;

  
  public function __construct() {
   
  }

  public function name() {
    return "{$this->name_} ";
  }

  public function setid($id){
    $this->id = $id ?? '';
  } 
 
  public function setSKU($SKU){
    $this->SKU = $SKU ?? '';
  } 

  public function setname_($_name){
    $this->name_ = $_name ?? '';
  } 

  public function setprice($price){
    $this->price = $price ?? '';
  } 

  public function setH($H){
    $this->H = $H ?? '';
  } 

  public function setW($W){
    $this->W = $W ?? '';
  } 

  public function setL($L){
    $this->L = $L ?? '';
  } 
  
  protected function validate() {
    $this->errors = [];

   
    return $this->errors;
  }


}

?>
