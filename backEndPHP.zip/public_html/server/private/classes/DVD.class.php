<?php

class DVD extends DatabaseObject {

  static protected $table_name = 'dvd';
  static protected $db_columns = ['id', 'id_el', 'SKU', 'name_', 'price', 'size'];

  public $id;
  public $id_el;
  public $SKU;
  public $name_;
  public $price;
  public $size;
  


  public function __construct() {
     
  }

  public function name() {
    return "{$this->name_} ";
  }

  public function setid($id){
    $this->id = $id ?? '';
  } 
 


  public function setSKU($SKU){
    $this->SKU = $SKU ?? '';
  } 

  public function setname_($_name){
    $this->name_ = $_name ?? '';
  } 

  public function setprice($price){
    $this->price = $price ?? '';
  } 

  public function setsize($size){
    $this->size = $size ?? '';
  } 

  protected function validate() {
    $this->errors = [];

    
    return $this->errors;
  }


}

?>
  