<?php

//This is the class that corresponds to the parent table I mentioned in the index.php file

class Product extends DatabaseObject {

  static protected $table_name = 'product';
  static protected $db_columns = ['id_', 'type_'];

  public $id_;
  public $type_;
  

  public function __construct() {
     
  }

  public function getid() {
    return $this->id_;
}


  public function gettype() {
    return "{$this->type_} ";
  }

 
 


  public function settype_($type_){
    $this->type_ = $type_ ?? '';
  } 

  
  
  
  protected function validate() {
    $this->errors = [];

  
    return $this->errors;
  }


}

?>
