<?php




define("DB_SERVER", "localhost");
define("DB_USER", "id18764269_root");
define("DB_PASS", "\}(BsBmPXC3P!crO");
define("DB_NAME", "id18764269_products");

?>
