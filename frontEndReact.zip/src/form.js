import React from 'react';
import axios from 'axios';
import { Dropdown, DropdownButton, Button } from 'react-bootstrap'
import { useEffect } from 'react';
import './App.css';
import { useNavigate } from 'react-router-dom';
import { Outlet } from "react-router-dom";



const AddForm = () => {

  const [formValue, setformValue] = React.useState({
    SKU: '',
    name_: '',
    price: '',
    weight: '',
    size:'',
    H: '',
    W: '',
    L:'',
    delete : 0
  });

  const [value,setValue]=React.useState('Book');
  const [formErrors, setformErrors] = React.useState({});
  const [isSubmit, setIsSubmit] = React.useState(false);
  const navigate = useNavigate();
  
  const handleSubmit = (event) => {
    
      event.preventDefault();
      setformErrors(validate(formValue));
      setIsSubmit(true); 
    }
      
      useEffect(() => {
        console.log(formErrors);
        if (Object.keys(formErrors).length === 0 && isSubmit) {
          console.log(formValue);
          value === 'Book' && (
            axios.post(`../../server/index.php/book`, 
              {
                SKU : formValue.SKU,
                name_ : formValue.name_,
                price : formValue.price,
                weight: formValue.weight,
                delete : 0
    
              }
            ))
            
          value === 'DVD' && (
            axios.post(`../../server/index.php/dvd`, 
              {
                SKU : formValue.SKU,
                name_ : formValue.name_,
                price : formValue.price,
                size: formValue.size,
                delete : 0
    
              }
            ))
    
          value === 'Furniture' && (
            axios.post(`../../server/index.php/furniture`, 
              {
                SKU : formValue.SKU,
                name_ : formValue.name_,
                price : formValue.price,
                H: formValue.H,
                W: formValue.W,
                L: formValue.L,
                delete : 0
    
              }
            ))
            window.setTimeout(() => {
              navigate('/');
           }, 1000) 
              
        }
      }, [formErrors]);

    const handleSelect=(event)=>{

      event.preventDefault()
      console.log(event.target.value);
      setValue(event.target.value)
        //I need to set value in order to save the selected type. Then, below,
        //according to the value, the last form inputs are rendered.
    }
  	//I also validate the inputs. I used for convenience the React state
  	//and save the errors in an array to display them and prevent for 
  	//submitting

    const handleChange = (event) => {
      setformValue({
         ...formValue,
         [event.target.name]: event.target.value
      });
    }

  const validate = (values) => {
  const regex_price = /[+-]?([0-9]*[.])?[0-9]+/g
  const regex_weight = /\b([1-9]|[1-9][0-9]|[1-9][0-9][0-9]|[1-9][0-9][0-9][0-9])\b/g
  const regex_size = /([1-9]|[1-9][0-9]|[1-9][0-9][0-9]|[1-9][0-9][0-9][0-9])/g
  //const regex_SKU = /[A-Z]{4}[0-9]{4}/;
  


  const errors = {}
  if(!values.price){
    errors.price = "Please submit required data"
  }
  else if (!regex_price.test(values.price)) {
    errors.price = "Please provide the data of indicated type";
  }

  if(!values.SKU){
    errors.SKU = "Please submit required data"
  }
  //else if (!regex_SKU.test(values.SKU)) {
    //errors.SKU = "Please provide the data of indicated type";
  //}

  if(!values.name_){
    errors.name_ = "Please submit required data"
  }
  
  if (value === 'Book'){
    if(!values.weight){
      errors.weight = "Please submit required data"
    }
    else if (!regex_weight.test(values.weight)) {
      errors.weight = "Please provide the data of indicated type";
  }
  }


  if (value === 'DVD'){
    if(!values.size){
     errors.size = "Please submit required data"
    }
    else if (!regex_size.test(values.size)) {
      errors.size = "Please provide the data of indicated type";
    }
  }

  if (value === 'Furniture'){

    if(!values.H){
      errors.H = "Please submit required data"
    }
    if(!values.W){
      errors.W = "Please submit required data"
    }
    if(!values.L){
     errors.L = "Please submit required data"
    }
  }
  return errors;
 }

  return (
    <><>
    
    <div class="container"> 
      <form onSubmit={handleSubmit}
        id = "product_form"
        >
  
        <div class="row border-bottom border-dark">
          <div class="col-10">
            <h2>Product Add</h2>
         </div>
        <div class="col-2">
          <Button type="submit" class="btn btn-primary">Save</Button>
          <Button class="btn btn-secondary" href = "/">Cancel</Button>
        </div>  
    </div>
    <div class="div-form">
      <div class="row">
        <div class="col-1">
          <h6>sku</h6>
        </div>
        <div class="col-sm-2">
          <input
          type="SKU"
          name="SKU"
          id="sku"
          placeholder="#sku"
          value={formValue.SKU}
          onChange={handleChange} />
          <p>{formErrors.SKU}</p>
        </div>
      </div>  

      <div class="row">
      <div class="col-1">
          <h6>Name</h6>
        </div>
        <div class="col-sm-2">
      <input
        type="name_"
        name="name_"
        id="name"
        placeholder="#name"
        value={formValue.name_}
        onChange={handleChange} />
        <p>{formErrors.name_}</p>
        </div>
      </div>

      <div class="row">
      <div class="col-1">
          <h6>Price</h6>
        </div>
        <div class="col-sm-2">
        <input
          type="price"
          name="price"
          id="price"
          placeholder="#price"
          value={formValue.price}
          onChange={handleChange} />
          <p>{formErrors.price}</p>
          </div>
      </div>

      </div>
      
      <div class="row">
        <div class="col-2">
          <h5>Type Switcher</h5> 
        </div>  
        <div class="col-2">
       

            <select id="productType" onChange={handleSelect} value={value}
            title = "type">
                  <option value="Book">Book</option>
                  <option value="DVD">DVD</option>
                  <option value="Furniture">Furniture</option>
               </select>
              

        </div>  
      </div>
      
      {value === 'Book' && (
        <>
        <div
        id ="book">
          <div class="row">
            <div class="col-1">
              <h6>Weight (KG)</h6>
            </div>
          <div class="col-sm-2">
            <input
            type="weight"
            name="weight"
            id="weight" 
            placeholder="#weight"
            value={formValue.weight}
            onChange={handleChange} />
            <p>Please provide weight in kilograms</p>
            <p>{formErrors.weight}</p>
          
          </div>
        </div>
        </div></>
      )}

      {value === 'DVD' && (
        <>
      <div id="DVD">
        <div class="row">
          <div class="col-1">
              <h6>Size (MB)</h6>
          </div>
           <div class="col-sm-2">
              <input
              type="size"
              name="size"
               id="size"
               placeholder="#size"
              value={formValue.size}
              onChange={handleChange} />
              <p>Please provide DVD size in mega bytes</p>
              <p>{formErrors.size}</p>
            </div> 
        </div>
      </div></>
      )}

      {value === 'Furniture' && (
        
        
        <div id="Furniture">

        <div class="row">
          <div class="col-1">
              <h6>Height (CM)</h6>
          </div>
          
         <div class="col-sm-2">
           <input
             type="H"
              id= "height"
              name="H"
              placeholder="#H"
              value={formValue.H}
              onChange={handleChange} />
              <p>{formErrors.H}</p>
            </div>
          </div>

        <div class="row">
          <div class="col-1">
            <h6>Width (CM)</h6>
          </div>

          <div class="col-sm-2">
            <input
             type="W"
              name="W"
              id="width"
               placeholder="#W"
              value={formValue.W}
              onChange={handleChange} />
               <p>{formErrors.W}</p>
            </div>
         </div> 

        <div class="row">
          <div class="col-1">
            <h6>Length (CM)</h6>
          </div>

          <div class="col-sm-2">
            <input
             type="L"
             name="L"
             id="length"
             placeholder="#L"
              value={formValue.L}
             onChange={handleChange} />
              <p>{formErrors.L}</p>
         </div>
        </div>
          <div>
            <p>Please provide dimensions in HxWxL format</p>
          </div>
        </div>
      )}
      </form>
  </div>
  <Outlet /></> 
    </>
  )
};

export default AddForm;
