import React from 'react';
import './App.css';
import Row from 'react-bootstrap/Row'
import Col from 'react-bootstrap/Col'
import Container from 'react-bootstrap/Container'

import axios from 'axios';
import { Outlet } from "react-router-dom";

//I decided to separate several funcionalities in type. This was convenient because I have in
// the database one table for each type. I didn't want to have only one table with a lot 
//nulls for better data quality

class ProductList extends React.Component {
  
    constructor(props){
      super(props);

      this.state ={
        items: [],
        DataisLoaded: false
      };

      this.state = { checkedBooks: [],
      checkedDVDs: [],
      checkedFurnitures: []};
      this.toggleCheckboxBook = this.toggleCheckboxBook.bind(this);

      this.deleteProducts = this.deleteProducts.bind(this);


      

    }

    //I save in an array which Ids from books, DVDs and Furniture and checked in order
    //to delete them
      
    toggleCheckboxBook = (e, item) => {		
      if(e.target.checked) {
        let arr = this.state.checkedBooks;
        arr.push(item.id);
        console.log(arr)
        this.setState = { checkedBooks: arr}
      } else {			
        let items = this.state.checkedBooks.splice(this.state.checkedBooks.indexOf(item.id), 1);
        this.setState = {
          checkedBooks: items
        }
      }		
      
    }

    toggleCheckboxDVD = (e, item) => {		
      if(e.target.checked) {
        let arr = this.state.checkedDVDs;
        arr.push(item.id);
        console.log(arr)
        this.setState = { checkedDVDs: arr}
        
      } else {			
        let items = this.state.checkedDVDs.splice(this.state.checkedDVDs.indexOf(item.id), 1);
        this.setState = {
          checkedDVDs: items
        }
      }		
      
    }
    
    toggleCheckboxFurniture = (e, item) => {		
      if(e.target.checked) {
        let arr = this.state.checkedFurnitures;
        arr.push(item.id);
        console.log(arr)
        this.setState = { checkedFurnitures: arr}
      } else {			
        let items = this.state.checkedFurnitures.splice(this.state.checkedFurnitures.indexOf(item.id), 1);
        this.setState = {
          checkedFurnitures: items
        }
      }		
     
    }

    deleteProducts() {
    
        this.state.checkedBooks.forEach(item => {
          axios.post(`../../server/index.php/book`, 
        {
          id : item,
          delete : 1
        }
      )
        })

        this.state.checkedDVDs.forEach(item => {
            axios.post(`../../server/index.php/dvd`, 
          {
            id : item,
            delete : 1
          }
        )
          })

        this.state.checkedFurnitures.forEach(item => {
              axios.post(`../../server/index.php/furniture`, 
            {
              id : item,
              delete : 1
            }
            )
            })

            setTimeout(()=>{
              window.location.href = '/'
          },2000);
          
          
          

          //const checkboxes = document.getElementsByClassName('delete-checkbox');
          //console.log(checkboxes)
            //for (let i=0; i<checkboxes.length;i++){
              //checkboxes[i].checked=true;}
         

      
    }

    addFunction() {
      window.location.href = '/add-product'

    }

	//Here I fetch all the products from the back end
    componentDidMount(){
      const requestOptions = {
        method: 'GET',
        headers: { 'Content-Type': 'application/json',
        'Access-Control-Allow-Origin':'',
        'Content-Type': 'multipart/form-data'
        }
    };

      fetch(`../../server/index.php/all`, requestOptions)
      .then((response) => response.json())
      .then(res => {
        this.setState({
          items: res,
          DataisLoaded: true
        });
      })
    }
    
    //this function render each product as a card (or a box). I used the fetched items which 
    //you can see below how it is mapped
    renderCardWidget(item) {
      
      if ('weight' in item){
        return(
          <div key = { item.id } 
          className="border border-dark"
          >
            <div>
            <input class="delete-checkbox" type="checkbox" value={item.id} id="flexCheckDefault" checked={this.state.checkedBooks.find((p) => p.id === item.id)} onChange={(e) => this.toggleCheckboxBook(e, item)}/>

            </div>
            <div>  
              <p className = "text-truncate text-center">
              {item.SKU } 
              </p>
              <p className = "text-truncate  text-center">
              {item.name_}
              </p>
              <p className = "text-truncate text-center">
              {item.price} $
              </p>
              <p className = "text-truncate text-center">
              Weight: {item.weight} kg
              </p>
            </div>
            
          </div> )
      }
      else if ('size' in item){
        return (
          <div key = { item.id } 
          className="border border-dark"
          >

          <div>
            <input 
            value = {item.id} type = "checkbox" id="flexCheckDefault"
            checked={this.state.checkedDVDs.find((p) => p.id === item.id)} onChange={(e) => this.toggleCheckboxDVD(e, item)}
            class = "delete-checkbox"
            />
          </div>

          <div>
            <p className = "text-truncate text-center">
            {item.SKU } 
            </p>
            <p className = "text-truncate  text-center">
            {item.name_}
            </p>
            <p className = "text-truncate text-center">
            {item.price} $
            </p>
            <p className = "text-truncate text-center">
            Size: {item.size} mb
            </p>
          </div>
        </div> )
      }
      else if ('H' in item){
        return (
        <div key = {item.id } 
        className="border border-dark"
        >
          <div>
          <input
          value = {item.id} type = "checkbox" id="flexCheckDefault"
          checked={this.state.checkedFurnitures.find((p) => p.id === item.id)} onChange={(e) => this.toggleCheckboxFurniture(e, item)}
          class = "delete-checkbox"
          />
          </div>
          <div>

            <p className = "text-truncate text-center">
            {item.SKU } 
            </p>
            <p className = "text-truncate  text-center">
            {item.name_}
            </p>
            <p className = "text-truncate text-center">
            {item.price} $
            </p>
            <p className = "text-truncate text-center">
            Dimension: {item.H}x{item.W}x{item.L}
            </p>
            </div>
          </div> )
      }
    }
    
      render(){
        const { DataisLoaded, items} = this.state;
        if (!DataisLoaded) return <div></div> ;
                                

        return (
            <>
      
        <div class="row border-bottom border-dark">
          <div class="col-10">
            <h2>Product List</h2>
          </div>
          <div class="col-2">
              <button type = "button" href="/add-product"
               class = "btn btn-secondary"
               onClick={this.addFunction}>ADD</button>
              <button class = "btn btn-secondary" type = "button"
              onClick={this.deleteProducts}>MASS DELETE</button>
          </div>  
        </div>
            
        <Container className="container-sm">
            <Row className="gap-5"
            >
              {items.map((item) => (
                <Col className="col-3"
                >
                  {this.renderCardWidget(item)}
                </Col>
              ))}
            </Row>  
        </Container>
       
        <Outlet />
        </>                    
);
}          
}
                       
  export default ProductList;
  
