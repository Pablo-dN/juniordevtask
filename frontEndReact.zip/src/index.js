import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import ProductList from './productList';
import 'bootstrap/dist/css/bootstrap.css';
import AddForm from './form';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'





export default function App() {
  return (
    <Router>
        <Routes>
          <Route exact path="/" element={<ProductList/>}/>
          <Route exact path="/add-product" element={<AddForm/>}/> 
        </Routes> 
    </Router>
    
  );
}

ReactDOM.render( 
  <App />,
  document.getElementById('content')
);


